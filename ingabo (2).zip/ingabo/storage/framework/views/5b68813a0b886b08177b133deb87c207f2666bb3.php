

<?php $__env->startSection('content'); ?>
            <section class="au-breadcrumb m-t-75">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="au-breadcrumb-content">
                                    <div class="au-breadcrumb-left">
                                        <span class="au-breadcrumb-span">You are here:</span>
                                        <ul class="list-unstyled list-inline au-breadcrumb__list">
                                            <li class="list-inline-item active">
                                                <a href="#">Dashboard</a>
                                            </li>
                                            <li class="list-inline-item seprate">
                                                <span>/</span>
                                            </li>
                                            <li class="list-inline-item">Vistor list</li>
                                        </ul>
                                    </div>
                                    <a href=" <?php echo e(route('manager.index')); ?>"class="au-btn au-btn-icon au-btn--green">
                                        <<<<<< Back </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END BREADCRUMB-->

           
            <section style="margin:30px">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">


                        <div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Phone number</th>
                                              
                                                <th>Birth</th>
                                                <th>District</th>
                                                <th>Sector</th>
                                                <th>Trial(s)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $vistors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($vistor->tel); ?></td>
                                                <td><?php echo e($vistor->birth); ?></td>
                                                <td><?php echo e($vistor->district); ?></td>
                                                <td> <?php echo e($vistor->sector); ?></td>
                                                <td>
                                                    <a  href="<?php echo e(route('manager.trial',['id'=>$vistor->id])); ?>"> 
                                                <?php echo e($vistor->trials_count); ?>

                                                    </a>
                                          
                                         

                                         
                                         
                                          
                                        
                                                </td>  
                                                
                                            </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                    <?php echo $vistors->links(); ?>

                                </div>
                                <!-- END DATA TABLE                  -->
                            </div>


                    </div>
                        
            </section>

            

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/manager/vistor.blade.php ENDPATH**/ ?>