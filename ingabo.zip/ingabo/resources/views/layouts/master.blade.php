<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Charts</title>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

    <!-- Fontfaces CSS-->
    <link href="{{asset('css/font-face.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/font-awesome-4.7/css/font-awesome.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/font-awesome-5/css/fontawesome-all.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/mdi-font/css/material-design-iconic-font.min.css')}}" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="{{asset('vendor/bootstrap-4.1/bootstrap.min.css')}}" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="{{asset('vendor/animsition/animsition.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/wow/animate.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/css-hamburgers/hamburgers.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/slick/slick.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/select2/select2.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('vendor/perfect-scrollbar/perfect-scrollbar.css')}}" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="{{asset('css/theme.css')}}" rel="stylesheet" media="all">
<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>



    <style>
        /*
        Read more here 
        http://codeconvey.com/animated-css3-checkbox-styling/
        */
        @import url(http://fonts.googleapis.com/css?family=Open+Sans);
        @import url('https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css');
        
        
        /*Page styles*/
        html { height: 100%; }
        
       
        
        /*Chickky Checkboxes styles*/
        .chickyboxes {
           
            float: left;
            padding: 5%;
            width: 100%;
            
        }
        .chickyboxes input[type="checkbox"] { display: none; }
        .chickyboxes input[type="checkbox"] + label {
          display: block;
          position: relative;
          padding-left: 35px;
          margin-bottom: 20px;
          font: 14px/20px 'Open Sans', Arial, sans-serif;
        
          cursor: pointer;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
        }
        .chickyboxes input[type="checkbox"] + label:last-child { margin-bottom: 0; }
        .chickyboxes input[type="checkbox"] + label:before {
          content: '';
          display: block;
          width: 20px;
          height: 20px;
          border: 1px solid blue;
          position: absolute;
          left: 0;
          top: 0;
          opacity: .6;
          -webkit-transition: all .12s, border-color .08s;
          transition: all .12s, border-color .08s;
        }
        .chickyboxes input[type="checkbox"]:checked + label:before {
          width: 10px;
          top: -5px;
          left: 5px;
          opacity: 1;
          border-top-color: transparent;
          border-left-color: transparent;
          -webkit-transform: rotate(45deg);
          transform: rotate(45deg);
        }
        
        /*Flat UI Design Checkboxes*/
        .flatboxes {
        
            float: left;
            padding: 5%;
            width: 40%;
            height:100px;	
        }
        .flatboxes p {
            display: block;
            height: 30px;
            vertical-align: middle;
        }
        .flatboxes [type="checkbox"]:not(:checked),
        .flatboxes [type="checkbox"]:checked {
          position: absolute; 
          left: -9999px;
        }
        .flatboxes [type="checkbox"]:not(:checked) + label,
        .flatboxes [type="checkbox"]:checked + label {
          position: relative;
          padding-left: 95px;
          cursor: pointer;
          color:#ddd;
        }
        .flatboxes [type="checkbox"]:not(:checked) + label:before,
        .flatboxes [type="checkbox"]:checked + label:before,
        .flatboxes [type="checkbox"]:not(:checked) + label:after,
        .flatboxes [type="checkbox"]:checked + label:after {
          content: '';
          position: absolute;
        }
        .flatboxes [type="checkbox"]:not(:checked) + label:before,
        .flatboxes [type="checkbox"]:checked + label:before {
          left: 0; top: 0;
          width: 80px; height: 30px;
          background: #DDDDDD;
          transition: background-color .2s;
        }
        .flatboxes [type="checkbox"]:not(:checked) + label:after,
        .flatboxes [type="checkbox"]:checked + label:after {
          width: 30px; height: 30px;
          transition: all .2s;
          background: #7F8C9A;
          top: 0; left: 0;
        }
        
        /* on checked */
        .flatboxes [type="checkbox"]:checked + label:before {
          background:#34495E; 
        }
        .flatboxes [type="checkbox"]:checked + label:after {
          background: #6cc0e5;
          top: 0; left: 51px;
        }
        
        .flatboxes [type="checkbox"]:checked + label .ui,
        .flatboxes [type="checkbox"]:not(:checked) + label .ui:before,
        .flatboxes [type="checkbox"]:checked + label .ui:after {
          position: absolute;
          left: 6px;
          width: 65px;
          font-size: 14px;
          font-weight: bold;
          line-height: 22px;
          transition: all .2s;
        }
        
        .flatboxes [type="checkbox"]:not(:checked) + label .ui:before {
          font-family: 'FontAwesome';
          content: "\f00d";
          left: 46px;
          margin-top: 3px;
        }
        .flatboxes [type="checkbox"]:checked + label .ui:after {
          font-family: 'FontAwesome';
          content: "\f00c";
          color: #6cc0e5;
          margin-top: 3px;
          left: 12px;
        }
        .flatboxes [type="checkbox"]:focus + label:before {
          border: 0; outline: 0;
          box-sizing: border-box;
        }
        
        
        
        /*Juice Checkboxes*/
        .juiceboxes {
            background: #3f3f3f none repeat scroll 0 0;
            float: left;
            padding: 5%;
            width: 40%;
            height:100px;
        }
        .juiceboxes input[type='radio'],
        .juiceboxes input[type='checkbox'] {
          display: none;
          cursor: pointer;
        }
        .juiceboxes input[type='radio']:focus, input[type='radio']:active,
        .juiceboxes input[type='checkbox']:focus,
        .juiceboxes input[type='checkbox']:active {
          outline: none;
        }
        .juiceboxes input[type='radio'] + label,
        .juiceboxes input[type='checkbox'] + label {
          cursor: pointer;
          display: inline-block;
          position: relative;
          padding-left: 30px;
          margin-right: 10px;
          color: #ddd;
        }
        .juiceboxes input[type='radio'] + label:before, input[type='radio'] + label:after,
        .juiceboxes input[type='checkbox'] + label:before,
        .juiceboxes input[type='checkbox'] + label:after {
          content: '';
          font-family: helvetica;
          display: inline-block;
          width: 20px;
          height: 20px;
          left: 0;
          bottom: 0;
          text-align: center;
          position: absolute;
        }
        .juiceboxes input[type='radio'] + label:before,
        .juiceboxes input[type='checkbox'] + label:before {
          background-color: #fafafa;
          -moz-transition: all 0.3s ease-in-out;
          -o-transition: all 0.3s ease-in-out;
          -webkit-transition: all 0.3s ease-in-out;
          transition: all 0.3s ease-in-out;
        }
        .juiceboxes input[type='radio'] + label:after,
        .juiceboxes input[type='checkbox'] + label:after {
          color: #fff;
        }
        .juiceboxes input[type='radio']:checked + label:before,
        .juiceboxes input[type='checkbox']:checked + label:before {
          -moz-box-shadow: inset 0 0 0 10px #6cc0e5;
          -webkit-box-shadow: inset 0 0 0 10px #6cc0e5;
          box-shadow: inset 0 0 0 10px #6cc0e5;
        }
        /*Checkbox Specific styles*/
        
        .juiceboxes input[type='checkbox'] + label:hover:after, 
        .juiceboxes input[type='checkbox']:checked + label:after {
          content: "\2713";
          line-height: 18px;
          font-size: 14px;
        }
        .juiceboxes input[type='checkbox'] + label:hover:after {
          color: #c7c7c7;
        }
        .juiceboxes input[type='checkbox']:checked + label:after, 
        .juiceboxes input[type='checkbox']:checked + label:hover:after {
          color: #fff;
        }
        
        /* demo */
        .codeconveyHeader {
            margin: 0 auto;
            text-align: center;
        }
        
        .codeconveyHeader h1 {
            color: #fff;
            font-size: 2em;
            font-weight: 700;
            margin: 50px 0 40px;
        }
        
        .codeconveyHeader h1 span {
            display: block;
            padding: 0 0 0.6em 0.1em;
            font-size: 0.6em;
            opacity: 0.7;
        }
        .demo {
          font-family: 'Raleway', sans-serif;
            color:#fff;
            display: block;
            margin: 0 auto;
            padding: 15px 0;
            text-align: center;
        }
        .demo a{
          font-family: 'Raleway', sans-serif;
        color: #2ecc71;		
        }
        
        
        
      
    
 
    .light {
      --primary: hsl(250, 100%, 44%);
      --other: hsl(0, 0%, 14%);
    
     
    }
    
    
    /* label */
    label {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      flex-wrap: nowrap;
    
      margin: 12px 0;
    
      cursor: pointer;
      position: relative;
    }
    
    
    /* input */
    .input {
      opacity: 0;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      z-index: -1;
    }
    
    
    /* .design */
    .design {
      width: 16px;
      height: 16px;
    
      border: 1px solid var(--other);
      border-radius: 100%;
      margin-right: 16px;
    
      position: relative;
    }
    
    .design::before,
    .design::after {
      content: "";
      display: block;
    
      width: inherit;
      height: inherit;
    
      border-radius: inherit;
    
      position: absolute;
      transform: scale(0);
      transform-origin: center center;
    }
    
    .design:before {
      background: var(--other);
      opacity: 0;
      transition: .3s;
    }
    
    .design::after {
      background: var(--primary);
      opacity: .4;
      transition: .6s;
    }
    
    
    /* .text */
    .text {
      color: var(--other);
      font-weight: bold;
    }
    
    
    /* checked state */
    input:checked+.design::before {
      opacity: 1;
      transform: scale(.6);
    }
    
    
    /* other states */
    input:hover+.design,
    input:focus+.design {
      border: 1px solid var(--primary);
    }
    
    input:hover+.design:before,
    input:focus+.design:before {
      background: var(--primary);
    }
    
    input:hover~.text {
      color: var(--primary);
    }
    
    input:focus+.design::after,
    input:active+.design::after {
      opacity: .1;
      transform: scale(2.6);
    }
    

    .footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: red;
  color: white;
  text-align: center;
}


    </style>


 

</head>

<body class="animsition bg-light">


   
        
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
          <div class="container">
              <a class="navbar-brand" href="{{ url('/') }}">
                  Ingabo App
              </a>

             
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                  <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <!-- Left Side Of Navbar -->
                  <ul class="navbar-nav mr-auto">

                  </ul>

                  <!-- Right Side Of Navbar -->
                  <ul class="navbar-nav ml-auto">
                      <!-- Authentication Links -->
                      <li class="nav-item">
                          <a class="nav-link"  href="lang/kiny" ><img style=" height:15px;width:20px" src="images/kiny.jpg"></a>
                      </li>
                        
                          <li class="nav-item">
                          <a class="nav-link"  href="lang/en" > <img style=" height:15px;width:20px" src="images/ng.jpg"></a>
                      </li>
                         
                          <li class="nav-item">
                        
                          <a class="nav-link"  href="lang/fr">  <img style=" height:15px;width:20px" src="images/fr.jpg"></a>
                      </li>
                        
                         
                         
                     
                  </ul>
              </div>
          </div>
      </nav>

      
         
                      

        

     
        <div class="row">
            <div class="col-lg-4">
            </div>


             @yield('content')

       

        <div class="col-lg-4">
        </div>

    </div>
    
       


</div>                     
     


    <!-- Jquery JS-->
    <script src="{{asset('vendor/jquery-3.2.1.min.js')}}"></script>
    <!-- Bootstrap JS-->
    <script src="{{asset('vendor/bootstrap-4.1/popper.min.js')}}"></script>
    <script src="{{asset('vendor/bootstrap-4.1/bootstrap.min.js')}}"></script>
    <!-- Vendor JS       -->
    <script src="{{asset('vendor/slick/slick.min.js')}}">
    </script>
    <script src="{{asset('vendor/wow/wow.min.js')}}"></script>
    <script src="{{asset('vendor/animsition/animsition.min.js')}}"></script>
    <script src="{{asset('vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')}}">
    </script>
    <script src="{{asset('vendor/counter-up/jquery.waypoints.min.js')}}"></script>
    <script src="{{asset('vendor/counter-up/jquery.counterup.min.js')}}">
    </script>
    <script src="{{asset('vendor/circle-progress/circle-progress.min.js')}}"></script>
    <script src="{{asset('vendor/perfect-scrollbar/perfect-scrollbar.js')}}"></script>
    <script src="{{asset('vendor/chartjs/Chart.bundle.min.js')}}"></script>
    <script src="{{asset('vendor/select2/select2.min.js')}}">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>


    <script>

function myFunction() {
  // Get the checkbox
  var checkBox = document.getElementById("myCheck");
  // Get the output text
  var text = document.getElementById("text");

  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}



function myFunction1() {
  // Get the checkbox
  var checkBox = document.getElementById("travel_contact");
  // Get the output text
  var text = document.getElementById("item_table");

  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}






    </script>


<script>
  $(document).ready(function(){


    $(document).on('click', '.add', function(){
  var html = '';
  html += '<tr>';
  html += '<input placeholder="amazina"  type="hidden" class="form-control form-control-sm" name="loop[]"  />';
  html += '<td><input placeholder="amazina"  type="text" class="form-control form-control-sm" name="name[]"  /></td>';
  html += '<td><input placeholder="email"  type="text" name="email[]" class="form-control form-control-sm" /></td>';
  html += '<td><input type="text" placeholder="telephone"  name="tel[]" class="form-control form-control-sm" /></td>';
  html += '<td><button type="button" name="remove" class="btn btn-danger btn-sm remove"><i class="fa fa-minus"></i></button></td></tr>';
  $('#item_table').append(html);
 });
 
   
   $(document).on('click', '.remove', function(){
    $(this).closest('tr').remove();
   });
   
   $('#insert_form').on('submit', function(event){
    event.preventDefault();
    var error = '';
    $('.item_name').each(function(){
     var count = 1;
     if($(this).val() == '')
     {
      error += "<p>Enter Item Name at "+count+" Row</p>";
      return false;
     }
     count = count + 1;
    });
    
    $('.item_quantity').each(function(){
     var count = 1;
     if($(this).val() == '')
     {
      error += "<p>Enter Item Quantity at "+count+" Row</p>";
      return false;
     }
     count = count + 1;
    });
    
    $('.item_unit').each(function(){
     var count = 1;
     if($(this).val() == '')
     {
      error += "<p>Select Unit at "+count+" Row</p>";
      return false;
     }
     count = count + 1;
    });
    var form_data = $(this).serialize();
    if(error == '')
    {
     $.ajax({
      url:"insert.php",
      method:"POST",
      data:form_data,
      success:function(data)
      {
       if(data == 'ok')
       {
        $('#item_table').find("tr:gt(0)").remove();
        $('#error').html('<div class="alert alert-success">Item Details Saved</div>');
       }
      }
     });
    }
    else
    {
     $('#error').html('<div class="alert alert-danger">'+error+'</div>');
    }
   });
   
  });
  </script>


<script>
    $(document).ready(function(){
      var date_input=$('input[name="date"]'); //our date input has the name "date"
      var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
      var options={
        format: 'mm/dd/yyyy',
        container: container,
        todayHighlight: true,
        autoclose: true,
      };
      date_input.datepicker(options);
    })
</script>



<script>
  $(function() {
      $('select[name=district]').change(function() {

          var url = '{{ url('district') }}' + $(this).val() + '/sectors/';

          $.get(url, function(data) {
              var select = $('form select[name= sector]');

              select.empty();

              $.each(data,function(key, value) {
                  select.append('<option value=' + value.id + '>' + value.name + '</option>');
              });
          });
      });
  });
</script>


<script>
  // In your Javascript (external .js resource or <script> tag)
    $(document).ready(function() {
$('.js-example-basic-single').select2();
});
</script>


</body>

</html>
<!-- end document-->
