

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">
    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 
    <div class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="fas fa-home"></i>Welcome</h3>
            
        </div>
        
        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
                   <form method="post" action="" >
                    <?php echo csrf_field(); ?>
                    <div class="alert alert-warning " role="alert"> Hitamo ibimenyetso byose waba ufite</div>

                    <hr>
                    <img style=" height:80px; width:80px" src="images/c.jpg">
                    <input style="font-size:1.2rem" name="symptom[]" value="cough" type="checkbox" id="cough">
                        <label  class="text-dark" for="cough">  <strong>Cough <strong></label>

                      <hr>       
                


                      <img style=" height:80px; width:80px" src="images/fever.jpg">
                      <input style="font-size:1.2rem" name="symptom[]" value="cough" type="checkbox" id="fever">
                          <label  class="text-dark" for="fever">  <strong>Fever <strong></label>



                            <hr>       
                


                            <img style=" height:80px; width:80px" src="images/sore.jpg">
                            <input style="font-size:1.2rem" name="symptom[]" value="cough" type="checkbox" id="sore">
                                <label  class="text-dark" for="sore">  <strong>Sore sthroad <strong></label>




                                    
                            <hr>       
                


                            <img style=" height:80px; width:80px" src="images/breath.jpg">
                            <input style="font-size:1.2rem" name="symptom[]" value="cough" type="checkbox" id="breath">
                                <label  class="text-dark" for="breath">  <strong>Breath shortage<strong></label>



                                    
                            <hr>       
                


                            <img style=" height:80px; width:80px" src="images/headache.jpg">
                            <input style="font-size:1.2rem" name="symptom[]" value="cough" type="checkbox" id="headache">
                                <label  class="text-dark" for="headache">  <strong>Headache <strong></label>
                    </div>
                  


                    

                        <button href="" type="submit" class="btn btn-primary btn-lg btn-block">
                            <i class="fa fa-location-arrow"></i> &nbsp; Komeza-continue-proceed
                        </button>
                    
                    </form>
                        
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/process/cough.blade.php ENDPATH**/ ?>