

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 

<div style="margin:10px" class="au-progress">
        
  <div class="au-progress__bar">
      <div class="au-progress__inner js-progressbar-simple" role="progressbar" data-transitiongoal="20">
          <span class="au-progress__value js-value"></span>
      </div>
  </div>
</div>

<div class="au-skill-container">
    
    <div class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
            <i class="fa fa-plane"></i><?php echo e(__('customlang.t_title')); ?></h3>
            
        </div>
        <div class="alert alert-warning " role="alert"> Subiza ibibazo bikurikira</div>

        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
            <form method="post" action="<?php echo e(route('handle.travel')); ?>">
                <?php echo csrf_field(); ?>





                <p>  <label   for="travel_history"><?php echo e(__('customlang.t_p1')); ?> ?</label></p>
                    
                  <section class="light">

                      
                    
                     
                    
                      <label>
                      <input class="input" id="myCheck" onclick="myFunction()" value="1" name="travel_history" type="radio" name="light">
                        <span class="design"></span>
                        <span class="text"><?php echo e(__('customlang.yes')); ?> </span>
                      </label>
                    
                      <label>
                        <input class="input" value="0" onclick="myFunction()" id="unCheck" type="radio" name="travel_history" >
                        <span class="design"></span>
                        <span class="text"><?php echo e(__('customlang.no')); ?> </span>
                      </label>


                      
          
 

                   


                 

                    <div id="text" style="display:none; pading:20px" >

                        <hr>



                        
                       


                        
                      

                       

                
                        
                        
                          
                          
                          <div class="col-sm-12">
                            
                          
                           <select name="country"  class="form-control"> 

                            <option value="" disabled selected hidden><?php echo e(__('customlang.t_country')); ?> </option>
                            <option value="USA"> USA </option>

                            <option value="UK"> UK </option>

                           </select>

                      
                        <hr>
                  
                       
                      
                        <label class="text-dark" for="travel_history"><?php echo e(__('customlang.t_p2')); ?> ?</label></p>
                    
                      
                       
                      <label>
                        <input class="input" id="myCheck" onclick="myFunction()" value="1" name="accompany" type="radio" name="light">
                          <span class="design"></span>
                          <span class="text"><?php echo e(__('customlang.yes')); ?> </span>
                        </label>
                      
                        <label>
                          <input class="input" value="0" onclick="myFunction()" id="unCheck" type="radio" name="accompany" >
                          <span class="design"></span>
                          <span class="text"><?php echo e(__('customlang.no')); ?> </span>
                        </label>




                       <hr>
                        
                        <label class="text-dark" for="travel_history"><?php echo e(__('customlang.t_p3')); ?> ?</label></p>
                    
                      
                       
                      <label>
                        <input class="input" id="myCheck" onclick="myFunction()" value="1" name="living" type="radio" name="light">
                          <span class="design"></span>
                          <span class="text"><?php echo e(__('customlang.yes')); ?> </span>
                        </label>
                      
                        <label>
                          <input class="input" value="0" onclick="myFunction()" id="unCheck" type="radio" name="living" >
                          <span class="design"></span>
                          <span class="text"><?php echo e(__('customlang.no')); ?> </span>
                        </label>
  

                          
                        

                          
                            
                          
                           
                        
                    
                    
                    
                   </div>
                
                  </div> 
                
                

                      
                    <button type="submit" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                      <?php echo e(__('customlang.proceed')); ?>    <i class="fas fa-arrow-right"></i></button>
                 
                 </form>


                 <div style="margin-top:20px" class="alert alert-light" role="alert">
                   <center class="text-primary"> <?php echo e(__('customlang.powered_by')); ?>   <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                   </div> 
                        
                </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/process/travel_history.blade.php ENDPATH**/ ?>