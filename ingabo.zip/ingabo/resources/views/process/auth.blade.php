
@extends('layouts.master')
@section('content')
    


<div class="col-lg-4">
    
    @if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif 

    <div style="margin:10px" class="au-progress">
        
        <div class="au-progress__bar">
            <div class="au-progress__inner js-progressbar-simple" role="progressbar" data-transitiongoal="20">
                <span class="au-progress__value js-value"></span>
            </div>
        </div>
    </div>

    
    <div class="au-card  m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="fa fa-user"></i>{{__('customlang.a_title')}}</h3>
            
        </div>
        <div class="alert alert-warning" role="alert">{{__('customlang.a_head')}}</div>
        
        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
                   <form method="post" action="{{route('handle.auth')}}" >
                    @csrf
                  
                    <div class="form-group">

                        <label for="vat" class=" form-control-label">{{__('customlang.phone')}}<span class="text-danger">*</span></label>

                          <input type="number" placeholder="0788443600" name="tel" class="form-control" required> 
                       
                        </div>

    
                        <div class="form-group">

                        <label for="vat" class=" form-control-label">{{__('customlang.birth')}}</label>

                        <input class="form-control" id="date" name="date" placeholder="MM/DD/YYY" type="date"/>
                       
                        </div>



                        




                            
                        <div class="form-group">

                            <label for="vat" class=" form-control-label">{{__('customlang.sector')}}</label>
                            <select class="js-example-basic-single form-control" name="sector" required>
                                <option value="" disabled selected hidden>shyiramo umurenge hano ....</option>
                                @foreach ($sectors as $value)
                            <option value="{{ $value->id }}">{{ $value->name}}</option>
                             @endforeach
    
                              </select>
                        
    
                           
                            </div>

    


        
                    
                  

                       

                        <button type="submit" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                            {{__('customlang.proceed')}}   <i class="fas fa-arrow-right"></i></button>
                    
                    </form>


                    <div style="margin-top:20px" class="alert alert-light" role="alert">
                      <center class="text-primary">  {{__('customlang.powered_by')}}  <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                      </div> 
                        
            </div>

            
        </div>
        
        
    </div>

    

</div>



  
@endsection

