

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">
    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 
    <div tyle="margin:20px" class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="fas fa-home"></i> </h3>
            
        </div>
        
        <div class="au-card-inner">
       
            
            <div style="margin:20px" class="chickyboxes">
                   <form method="post" action="<?php echo e(route('handle.notice')); ?>" >
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="vat" class=" form-control-label">Hitamo ururimi-Select the language-choisir la langue</label>
                        <center>
                        <div class="btn-group">
                           
                        <a class="nav-link"  href="lang/kiny" ><img style=" height:30px;width:35px" src="images/kiny.jpg"></a>
                        <a class="nav-link"  href="lang/en" > <img style="  height:30px;width:35px" src="images/ng.jpg"></a>
                        <a class="nav-link"  href="lang/fr">  <img style="  height:30px;width:35px" src="images/fr.jpg"></a>
                        
                          
                    
                    </div>
                </center>
                        <input >
                    </div>
                  

                        <button href="" type="submit" class="btn btn-success btn-lg btn-block">
                            <i class="fa fa-location-arrow"></i> &nbsp; Komeza-continue-proceed
                        </button>
                    
                    </form>
                        
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/process/welcome.blade.php ENDPATH**/ ?>