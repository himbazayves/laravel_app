

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">
    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 

    <div style="margin:10px" class="au-progress">
        
        <div class="au-progress__bar">
            <div class="au-progress__inner js-progressbar-simple" role="progressbar" data-transitiongoal="20">
                <span class="au-progress__value js-value"></span>
            </div>
        </div>
    </div>

    
    <div class="au-card  m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="fa fa-user"></i><?php echo e(__('customlang.a_title')); ?></h3>
            
        </div>
        <div class="alert alert-warning" role="alert"><?php echo e(__('customlang.a_head')); ?></div>
        
        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
                   <form method="post" action="<?php echo e(route('handle.auth')); ?>" >
                    <?php echo csrf_field(); ?>
                  
                    <div class="form-group">

                        <label for="vat" class=" form-control-label"><?php echo e(__('customlang.phone')); ?><span class="text-danger">*</span></label>

                          <input type="number" placeholder="0788443600" name="tel" class="form-control" required> 
                       
                        </div>

    
                        <div class="form-group">

                        <label for="vat" class=" form-control-label"><?php echo e(__('customlang.birth')); ?></label>

                        <input class="form-control" id="date" name="date" placeholder="MM/DD/YYY" type="date"/>
                       
                        </div>



                        




                            
                        <div class="form-group">

                            <label for="vat" class=" form-control-label"><?php echo e(__('customlang.sector')); ?></label>
                            <select class="js-example-basic-single form-control" name="sector">
                                <option value="" disabled selected hidden>shyiramo umurenge hano ....</option>
                                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                              </select>
                        
    
                           
                            </div>

    


        
                    
                  

                       

                        <button type="submit" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                            <?php echo e(__('customlang.proceed')); ?>   <i class="fas fa-arrow-right"></i></button>
                    
                    </form>


                    <div style="margin-top:20px" class="alert alert-light" role="alert">
                      <center class="text-primary">  <?php echo e(__('customlang.powered_by')); ?>  <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                      </div> 
                        
            </div>

            
        </div>
        
        
    </div>

    

</div>



  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/process/auth.blade.php ENDPATH**/ ?>