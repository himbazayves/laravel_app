

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 

<div style="margin:10px" class="au-skill-container">
    <div class="au-progress">
        
        <div class="au-progress__bar">
            <div class="au-progress__inner js-progressbar-simple" role="progressbar" data-transitiongoal="80">
                <span class="au-progress__value js-value"></span>
            </div>
        </div>
    </div>
    <div class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="far fa-people-arrows"></i><?php echo e(__('customlang.c_title')); ?></h3>
            
        </div>
      
        <div class="alert alert-warning " role="alert"><?php echo e(__('customlang.c_head')); ?></div>

        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
            <form method="post" action="<?php echo e(route('handle.contact_history')); ?>">
                <?php echo csrf_field(); ?>





                  <label   for="travel_history"><?php echo e(__('customlang.c_p1')); ?>?</label>
                    
                  <section class="light">

                      
                    
                     
                    
                      <label>
                      <input class="input" id="myCheck" onclick="myFunction()" value="1" name="contact_history" type="radio" name="light">
                        <span class="design"></span>
                        <span class="text"><?php echo e(__('customlang.yes')); ?></span>
                      </label>
                    
                      <label>
                        <input class="input" value="0" onclick="myFunction()" id="unCheck" type="radio" name="contact_history" >
                        <span class="design"></span>
                        <span class="text"><?php echo e(__('customlang.no')); ?></span>
                      </label>


                      
          
 

                   


                 




                        
                       


                        
                      

                       

                
                        
                        
                          
                        
                  
                       
                      



                       
  

                          
                        

                          
                            
                          
                           
                        
                    
                    
                    
                   </div>
                
                    
                
                
                   <button type="submit" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                    Komeza   <i class="fas fa-arrow-right"></i></button>
               
               </form>


               <div style="margin-top:20px" class="alert alert-light" role="alert">
                 <center class="text-primary">  Powered by  <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                 </div> 
                   
                </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/process/contact_history.blade.php ENDPATH**/ ?>