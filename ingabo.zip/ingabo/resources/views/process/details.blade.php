
@extends('layouts.master')
@section('content')
    


<div class="col-lg-6">

    @if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif 

<div style="margin:10px" class="au-progress">
        
    <div class="au-progress__bar">
        <div class="au-progress__inner js-progressbar-simple" role="progressbar" data-transitiongoal="95">
            <span class="au-progress__value js-value"></span>
        </div>
    </div>
</div>
    <div class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
            <i class="fa fa-plane"></i>{{__('customlang.d_title')}}</h3>
            
        </div>
       <div class="alert alert-warning " role="alert">{{__('customlang.d_head')}}</div>
            
                   

        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
            <form method="post" action="{{route('handle.detail')}}">
                @csrf

                   

                 

                
                    <span id="error"></span>
                    <table class="table  table-borderless " id="item_table">
                     <tr>
                      <th>{{__('customlang.d_name')}} </th>
                      <th>{{__('customlang.d_email')}}</th>
                      <th>{{__('customlang.d_phone')}}</th>
                      <th><button type="button" name="add" class="btn btn-success btn-sm add"><i class="fa fa-plus"></i></button></th>
                     </tr>
                     <input placeholder="amazina" type="hidden" value="1" class="form-control form-control-sm" name="loop[]"/>
                   
                     <td><input placeholder="amazina" type="text" class="form-control form-control-sm" name="name[]"  /></td>
                     <td><input placeholder="Email" name="email[]" class="form-control form-control-sm" /></td>
                     <td><input type="text" placeholder="telephone" name="tel[]" class="form-control form-control-sm" /></td>

                    </table>
                
                    
                
                

                    <button type="submit" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                        {{__('customlang.proceed')}}  <i class="fas fa-arrow-right"></i></button>
                   
                   </form>
    
    
                   <div style="margin-top:20px" class="alert alert-light" role="alert">
                     <center class="text-primary">  {{__('customlang.powered_by')}}  <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                     </div> 
                       
                    </div>
                        
                </div>
        </div>
    </div>
</div>

@endsection

