

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">
    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 


<div style="margin:20px"class="sufee-alert alert with-close alert-success alert-dismissible fade show">
    <span class="badge badge-pill badge-success">Success</span>
    Conglatulations you have done your test.
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
    <div class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="far fa-books-medical"></i> <?php echo e(__('customlang.f_title')); ?>  </h3>
            
        </div>
        
        <div class="au-card-inner">

            

       
            
            <div class="chickyboxes">
                   


                    <div class="card-body">


                        <P>
                 
                          <?php
                              
                              {{
                                  
                                if ($result==0){

                                 echo"<div class='alert alert-success role='alert'>  {{__('customlang.f_normal')}}  </div>";
            
                              }
                            
                              else{
                                echo"  <div class='alert alert-success role='alert'>  {{__('customlang.f_severe')}}  </div>";


                              }

                                
                            
                            }}

                          ?>
                            
                            
                          
            
                        




                        
                        <div>
                 
                            <hr> 
                              
                              
                              <div class="alert alert-warning"> 



                               <p> <?php echo e(__('customlang.f_p')); ?> </p>
                              

                           

                               <table class="table">
                                <thead>
                                  <tr>
                                    <th scope="col"> <?php echo e(__('customlang.f_center')); ?> </th>
                                    <th scope="col"> <?php echo e(__('customlang.f_contact')); ?> </th>
                                   
                                  </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $center->centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                   
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->contact); ?> </td>
                                    
                                  </tr>
                                
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                                   
                                
                   
                                   
                            
                                 
                        
                        </div>
              
                        </div>



                   

              
                  

                    </div>


                    
                <a href="<?php echo e(route('process.auth')); ?>" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                        <i class="fas fa-arrow-left"></i>  <?php echo e(__('customlang.restart')); ?>    </a>
                   

                        <button type="submit" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                          <?php echo e(__('customlang.f_tips')); ?>   <i class="fas fa-arrow-right"></i></button>
                       
                   


                   <div style="margin-top:20px" class="alert alert-light" role="alert">
                     <center class="text-primary">  <?php echo e(__('customlang.powered_by')); ?>  <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                     </div> 
                        
                   
                        
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/handle/feedback.blade.php ENDPATH**/ ?>