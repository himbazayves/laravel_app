

<?php $__env->startSection('content'); ?>
    


<div class="col-lg-4">
    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 
    <div style="margin-top:30px" class="au-card m-b-30">
        <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
            <div class="bg-overlay bg-overlay--blue"></div>
            <h3>
                <i class="fas fa-exclamation-triangle"></i><?php echo e(__('customlang.n_title')); ?> </h3>
            
        </div>
        <div class="alert alert-warning" role="alert"> <?php echo e(__('customlang.n_head')); ?></div>
        
        <div class="au-card-inner">
        
        <div class="au-card-inner">
       
            
            <div class="chickyboxes">
                 
                 



                    <div class="card-body">
                        <div class="alert alert-light" role="alert">
                         
                            <p> <?php echo e(__('customlang.n_p1')); ?></p>
                            <hr>
                            <p class="mb-0"> <?php echo e(__('customlang.n_p2')); ?></p>
                        </div>

                   

                <div class ="alert-danger" role="alert">

                  <p> <i class="fas fa-exclamation-triangle"></i><?php echo e(__('customlang.n_warning')); ?> </p>
                </div>

                  

                    </div>
                  

                <a href="<?php echo e(route('process.auth')); ?>" class="au-btn au-btn-icon au-btn--green btn btn-outline-sucess btn-block">
                        Tangira   <i class="fas fa-arrow-right"></i></a>
                   
                        <div style="margin-top:20px" class="alert alert-light" role="alert">
                            <center class="text-primary">  Powered by  <img style="height:60px;width:60px" src="images/logo.jpg"><strong> Rurarera inc <strong></center>
                            </div>       
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\ingabo\ingabo\resources\views/process/notice.blade.php ENDPATH**/ ?>